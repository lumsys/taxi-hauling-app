<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Trip;
use App\DriverPlatenumber;
use Auth;
use Carbon\Carbon;

class BMController extends Controller
{
    public function index(){
    	 
    	$r_driver_count = DriverPlatenumber::where('region_id',Auth::user()->region_id)->count();
    	$total_r_driver_count = DriverPlatenumber::count();
    	$users = DriverPlatenumber::where('region_id',Auth::user()->region_id)->get();

    	$from =   '0000000000';
        $from=date('Y-m-d H:i:s',strtotime($from));
        $to =  Carbon::now();
        $to=date('Y-m-d H:i:s',strtotime($to));
 
	     $previous_week = strtotime("-1 week +1 day");
	     $start_week = strtotime("last sunday midnight",$previous_week);
	     $end_week = strtotime("next saturday",$start_week);
	     $start_week = date("Y-m-d",$start_week);
	     $end_week = date("Y-m-d",$end_week);

    	$drivers = collect([]);
    	$items = collect();
 		
 		$tripAmt =0;
 		$tripCount =0;
 		$tripAmtDay =0;
 		$tripDayCount =0;

        foreach($users as $key => $name){
        $tripAmt +=  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->sum('tripAmt');
         $tripCount +=  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->count();
         $tripAmtDay += Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->sum('tripAmt');
          $tripDayCount += Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->count();
       }
      
    	return view('BM.dashboard',compact('r_driver_count','total_r_driver_count','tripAmt','tripCount','tripAmtDay','tripDayCount'));
    }

    public function regionDrivers(){
    	$users = DriverPlatenumber::where('region_id',Auth::user()->region_id)->get();

    	 $from =   '0000000000';
        $from=date('Y-m-d H:i:s',strtotime($from));
        $to =  Carbon::now();
        $to=date('Y-m-d H:i:s',strtotime($to));
        
         $drivers = collect([]);
      //   $users=  User::where(['userType' => 'driver', 'isAvailable' => 'online' ])->get();
      //  $drivers =  Trip::whereBetween('created_at', [$from, $to])->where(['business_code' => Auth::user()->unique_code, 'tripRequest' => 'approved', 'flag' => 0])->get();
      //return view('business.trips2', compact('trips'));
 
     $previous_week = strtotime("-1 week +1 day");
     $start_week = strtotime("last sunday midnight",$previous_week);
     $end_week = strtotime("next saturday",$start_week);
     $start_week = date("Y-m-d",$start_week);
     $end_week = date("Y-m-d",$end_week);
 
        foreach($users as $key => $name){
  
        $tripAmt =  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->sum('tripAmt');
         $tripCount =  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->count();
         $tripAmtDay = Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->sum('tripAmt');
          $tripDayCount = Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->count();
          $tripAmtLastWeek = Trip::where('driverId', $name->user_id)->whereBetween('created_at', [$start_week, $end_week])->whereNotNull('tripAmt')->where(['tripRequest' => 'approved'])->sum('tripAmt');
          $tripAmtLastWeekCount = Trip::where('driverId', $name->user_id)->whereBetween('created_at', [$start_week, $end_week])->whereNotNull('tripAmt')->where(['tripRequest' => 'approved'])->count();
 
         $drivers->put($key,[
             'tripAmt'=>$tripAmt,
             'tripCount'=>$tripCount,
             'name' => $name->user->name,
             'phone'=>$name->user->phone,
             'region' => $name->region->name,
             'tripAmtDay'=>$tripAmtDay,
             'tripDayCount'=>$tripDayCount,
             'tripAmtLastWeek'=> $tripAmtLastWeek,
             'tripAmtLastWeekCount'=> $tripAmtLastWeekCount
         ]);
       }
    	return view('BM.driver_list',compact('drivers'));
    }

    public function allRegionDrivers(){

    	$users = DriverPlatenumber::all();
    	$from =   '0000000000';
        $from=date('Y-m-d H:i:s',strtotime($from));
        $to =  Carbon::now();
        $to=date('Y-m-d H:i:s',strtotime($to));
        
         $drivers = collect([]);
      //   $users=  User::where(['userType' => 'driver', 'isAvailable' => 'online' ])->get();
      //  $drivers =  Trip::whereBetween('created_at', [$from, $to])->where(['business_code' => Auth::user()->unique_code, 'tripRequest' => 'approved', 'flag' => 0])->get();
      //return view('business.trips2', compact('trips'));
 
     $previous_week = strtotime("-1 week +1 day");
     $start_week = strtotime("last sunday midnight",$previous_week);
     $end_week = strtotime("next saturday",$start_week);
     $start_week = date("Y-m-d",$start_week);
     $end_week = date("Y-m-d",$end_week);
 
        foreach($users as $key => $name){
  
        $tripAmt =  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->sum('tripAmt');
         $tripCount =  Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->where([ 'tripRequest' => 'approved'])->whereBetween('created_at', [$from, $to])->count();
         $tripAmtDay = Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->sum('tripAmt');
          $tripDayCount = Trip::where('driverId', $name->user_id)->whereNotNull('tripAmt')->whereYear('created_at',date("Y"))->whereMonth('created_at',date("m"))->whereDay('created_at', date("d"))->where(['tripRequest' => 'approved'])->count();
          $tripAmtLastWeek = Trip::where('driverId', $name->user_id)->whereBetween('created_at', [$start_week, $end_week])->whereNotNull('tripAmt')->where(['tripRequest' => 'approved'])->sum('tripAmt');
          $tripAmtLastWeekCount = Trip::where('driverId', $name->user_id)->whereBetween('created_at', [$start_week, $end_week])->whereNotNull('tripAmt')->where(['tripRequest' => 'approved'])->count();
 
         $drivers->put($key,[
             'tripAmt'=>$tripAmt,
             'tripCount'=>$tripCount,
             'name' => $name->user->name,
             'phone'=>$name->user->phone,
             'region' => $name->region->name,
             'tripAmtDay'=>$tripAmtDay,
             'tripDayCount'=>$tripDayCount,
             'tripAmtLastWeek'=> $tripAmtLastWeek,
             'tripAmtLastWeekCount'=> $tripAmtLastWeekCount
         ]);
       }
    	return view('BM.all_driver_list',compact('drivers'));
    }
}
